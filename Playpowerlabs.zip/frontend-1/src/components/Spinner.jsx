import React from 'react'
const Spinner = () => {
  return (
    <span className="spinner" aria-label="Loading"></span>
  );
}

export default Spinner;